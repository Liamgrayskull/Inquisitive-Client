Created by rikitikitivi

Content:

ARMOR SETS

Legionary
Centurion
Legate
Ceasar
Magnate
Senator
Gladiator
Hunter
Romulus
Remus

Psiloi
Hoplite
Pharaoh
Guardian
Olympus
Angel
Atlantis

Leather Viking
Studded Viking
Golden Viking
Iron Viking
Diamond Viking
Neherite Viking
Brown Berserk
Gray Berserk
Black Berserk
Thor
Night King

Brown Ronin
Black Ronin
Brown Samurai
Blue Samurai
Red Samurai
White Samurai
Black Samurai
Brown Daimyo
Green Daimyo
Red Daimyo
White Daimyo
Black Daimyo

Merchant
Jarl
Climber
Winter Guard
Woodland
Firebender
Aquanaut
Wizard
Doctor
Raider
Wasteland
Mandalorian
Gray Wolf
Black Wolf
Red Fox
Snow Fox
Bear
Invisible

HEADWEAR

Red Bandana
Scuba Mask
Brown Mengu
Green Mengu
Red Mengu
White Mengu
Black Mengu

PUMPKIN

Sando Hat

ELYTRA

Fancy
Wasteland
Brown Daimyo
Green Daimyo
Red Daimyo
White Daimyo
Black Daimyo
Invisible
